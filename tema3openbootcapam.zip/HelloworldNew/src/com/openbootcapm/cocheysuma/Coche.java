package com.openbootcapm.cocheysuma;

import java.util.Random;

public class Coche {
    int puerta =1;

    public static void main(String[] args) {

        Coche CocheMain = new Coche();
        CocheMain.puerta+=1;
        System.out.println(CocheMain.puerta);



    }
}







